<?php
/**
 * Plugin Name: Rapid Tests Tabs
 * Plugin URI: https://yourwebsite.com/
 * Description: A plugin that adds a custom post type 'Rapid Tests' and a shortcode `[rapid_tests_tabs]` to display a tabbed interface for rapid tests.
 * Version: 1.0
 * Author: Dushyant Verma
 * Author URI: https://yourwebsite.com/
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Register Custom Post Type: Rapid Tests
function register_rapid_tests_cpt() {
    $labels = array(
        'name'               => 'Rapid Tests',
        'singular_name'      => 'Rapid Test',
        'menu_name'          => 'Rapid Tests',
        'name_admin_bar'     => 'Rapid Test',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Rapid Test',
        'new_item'           => 'New Rapid Test',
        'edit_item'          => 'Edit Rapid Test',
        'view_item'          => 'View Rapid Test',
        'all_items'          => 'All Rapid Tests',
        'search_items'       => 'Search Rapid Tests',
        'not_found'          => 'No Rapid Tests found.',
        'not_found_in_trash' => 'No Rapid Tests found in Trash.',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable'  => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'rapid-tests'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array('title', 'editor', 'thumbnail'),
        'show_in_rest'       => true,
    );

    register_post_type('rapid-tests', $args);
}
add_action('init', 'register_rapid_tests_cpt');

// Register the shortcode function
function rapid_tests_tabs_shortcode() {
    ob_start();

    $args = array(
        'post_type'      => 'rapid-tests',
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
    );
    $rapid_tests = new WP_Query($args);

    if ($rapid_tests->have_posts()) {
        $tabs = [];
        $content_data = [];
        $default_image = ''; 
        $default_text = ''; 

        echo '<div class="content-container" id="content">';
        echo '<div class="curve"></div>';
        echo '<div class="image-row">';

        while ($rapid_tests->have_posts()) {
            $rapid_tests->the_post();
            $post_id = get_the_ID();
            $title = get_the_title();
            $content = get_the_content();
            $image_url = get_the_post_thumbnail_url($post_id, 'full') ?: 'default-image.jpg';

            if (empty($default_image)) {
                $default_image = $image_url;
                $default_text = apply_filters('the_content', $content);
            }

            $content_data[$title] = [
                'image' => $image_url,
                'text' => apply_filters('the_content', $content) 
            ];

            echo '<img class="content-image" src="' . esc_url($image_url) . '" alt="' . esc_attr($title) . '" data-tab="' . esc_attr($title) . '">';
            
            $tabs[] = '<div class="tab" data-tab="' . esc_attr($title) . '">' . esc_html($title) . '</div>';
        }

        echo '</div>'; 
        echo '</div>'; 

        // Tab Navigation
        echo '<div class="tab-container" id="tabs">';
        echo implode('', $tabs);
        echo '</div>';

        echo '<div class="content-container">';
        echo '<div id="content-text"></div>'; 
        echo '</div>';

        wp_reset_postdata();
    } else {
        echo '<p>No rapid tests found.</p>';
    }
    ?>
    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const tabs = document.querySelectorAll(".tab");
            const contentText = document.getElementById("content-text");
            const images = document.querySelectorAll(".content-image");
            const tabData = <?php echo json_encode($content_data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            
            contentText.innerHTML = `<?php echo wp_kses_post($default_text); ?>`;

            if (images.length > 0) {
                images[0].classList.add("active-image");
            }

            tabs.forEach((tab, index) => {
                tab.addEventListener("click", function () {
                    document.querySelector(".tab.active")?.classList.remove("active");
                    tab.classList.add("active");

                    const tabName = tab.getAttribute("data-tab");

                    if (tabData[tabName]) {
                        contentText.innerHTML = tabData[tabName].text;
                    }

                    images.forEach(img => img.classList.remove("active-image"));
                    images[index].classList.add("active-image");
                });
            });
        });
    </script>

    <style>
       	.content-container:first-child {
    padding-top: 100px;
}

        .tab-container {
            display: flex;
			justify-content: space-evenly;
            background: #190046;
            padding: 20px;
        }
        .tab {
            padding: 6px 20px;
            cursor: pointer;
            background: transparent;
            margin: 0 5px;
            color: #B3ABC2;
            font-size: 18px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .tab.active {
            background: #2850F5;
            color: white;
            border-radius: 30px;
        }

        .content-container {
            border-radius: 0;
            width: 100%;
            margin-left: auto;
            justify-content: center;
            display: flex;
            background: #190046;
            position: relative;
            overflow: hidden;
            flex-direction: column;
            align-items: center;
            padding-top: 5px; /* Space for curve */
        }

        div#content-text {
            background: #2850F5;
            padding: 40px 160px;
			color: #E9EDFE;
			height: 210px;
			
			width: 100%;
        }

        /* Image Row */
        .image-row {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
            padding: 20px;
            width: 80%;
            position: relative;
        }
.content-image {
    width: 180px;
    height: 250px;
    object-fit: cover;
    transition: transform 0.3s ease-in-out, width 0.3s ease-in-out, height 0.3s ease-in-out, margin-top 0.3s ease-in-out;
    cursor: pointer;
    border-radius: 10px;
}
        .content-image.active-image {
			 width: 180px;
    height: 220px;
            transform: scale(1.2);
            margin-top: -20px; /* Slide up effect */
        }

        #content-text ul {
            list-style: none; /* Remove default bullets */
            padding: 0;
        }

        #content-text ul li {
            position: relative;
            padding-left: 25px; /* Space for the arrow */
        }

        #content-text ul li::before {
            font-family: "Font Awesome 6 Free"; /* FontAwesome family */
            content: "\f061"; /* Unicode for right arrow */
            font-weight: 900; /* Solid icon */
            position: absolute;
            left: 0;
            color: #FFF; /* Arrow color */
        }

		/* @media (max-width: 768px){
			.tab-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-evenly;
    background: #190046;
    padding: 20px;
}

div#content-text {
    padding: 20px; }
		} */

		@media (max-width: 1024px) {
    /* Make tabs more compact */
    .tab-container {
        flex-wrap: wrap;
        justify-content: center;
        overflow-x: auto;
        padding: 15px;
    }
    
    .tab {
        font-size: 16px;
        padding: 8px 15px;
        white-space: nowrap; /* Prevent text wrapping */
    }

    /* Reduce padding for content text */
    div#content-text {
        padding: 30px;
        font-size: 16px;
        height: auto;
    }
    
    /* Adjust image row */
    .image-row {
        flex-wrap: wrap;
        gap: 10px;
        padding: 10px;
        width: 90%;
    }
    
    .content-image {
        width: 180px;
        height: 260px;
        border-radius: 8px;
    }
    
    .content-image.active-image {
        transform: scale(1.1);
        margin-top: -10px;
    }
}

@media (max-width: 768px) {
    /* Center align tab text */
    .tab-container {
        display: flex;
        flex-wrap: nowrap;
        justify-content: flex-start;
        overflow-x: auto;
        white-space: nowrap;
        padding: 10px;
        gap: 10px;
        -webkit-overflow-scrolling: touch; /* Smooth scrolling on mobile */
    }

    .tab {
        font-size: 14px;
        padding: 6px 12px;
        border-radius: 20px;
        flex-shrink: 0; /* Prevent shrinking */
    }
    
    /* Adjust content section */
    div#content-text {
        padding: 20px;
        font-size: 14px;
        line-height: 1.5;
    }
    
    /* Resize images dynamically */
    .content-image {
        width: 150px;
        height: 220px;
    }
    
    .content-image.active-image {
        transform: scale(1.1);
        margin-top: -5px;
    }
}

@media (max-width: 480px) {
    /* Tabs should be scrollable */
	.tab-container {
        flex-wrap: wrap;
        justify-content: center;
        padding: 10px;
        gap: 8px;
    }

    .tab {
        font-size: 13px;
        padding: 5px 10px;
    }

    /* Reduce content padding */
    div#content-text {
        padding: 15px;
        font-size: 13px;
    }

    /* Stack images properly */
    .image-row {
        flex-direction: column;
        align-items: center;
    }

    .content-image {
        width: 120px;
        height: 180px;
    }

    .content-image.active-image {
        transform: scale(1.05);
    }
}
    </style>

    <?php
    return ob_get_clean();
}
add_shortcode('rapid_tests_tabs', 'rapid_tests_tabs_shortcode');


// Add "How to Use" Submenu under "Rapid Tests" Post Type
function rapid_tests_add_submenu_page() {
    add_submenu_page(
        'edit.php?post_type=rapid-tests', // Parent slug (Rapid Tests CPT)
        'How to Use',                     // Page Title
        'How to Use',                     // Menu Title
        'manage_options',                  // Capability
        'rapid-tests-how-to-use',          // Menu Slug
        'rapid_tests_how_to_use_page'      // Callback function
    );
}
add_action('admin_menu', 'rapid_tests_add_submenu_page');

// Callback Function: Display How to Use Instructions
function rapid_tests_how_to_use_page() {
    ?>
    <div class="wrap">
        <h1>How to Use the Rapid Tests Plugin</h1>
        <p>This plugin allows you to create and display "Rapid Tests" using a tabbed interface.</p>
        
        <h2>📌 Step 1: Add a New Rapid Test</h2>
        <p>Navigate to <strong>Rapid Tests → Add New</strong> and create new rapid test posts.</p>
        <ul>
            <li>Enter the <strong>title</strong> of the test (this will be the tab name).</li>
            <li>Use the <strong>content area</strong> to describe the test.</li>
            <li>Set a <strong>featured image</strong> (this will be displayed in the tab layout).</li>
            <li>Click <strong>Publish</strong>.</li>
        </ul>

        <h2>📌 Step 2: Display the Tests on Your Website</h2>
        <p>To display the Rapid Tests tab layout, simply add the following shortcode to any page or post:</p>
        <pre><code>[rapid_tests_tabs]</code></pre>
        
        <h2>📌 Step 3: Customize the Display</h2>
        <p>The shortcode will automatically pull all Rapid Tests and create a tabbed layout with images. The first test is selected by default.</p>

        <h2>📌 Additional Notes</h2>
        <ul>
            <li>The order of the tabs follows the order of published Rapid Tests (newest first).</li>
            <li>If no featured image is set, a default placeholder image will be used.</li>
        </ul>

        <p><strong>Need Help?</strong> Reach out to support for assistance.</p>
    </div>
    <?php
}
